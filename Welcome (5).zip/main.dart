
import 'package:flutter/material.dart';
import 'package:sujata_ai/pages/login_page.dart';

void main() {
  runApp(SujataAIApp());
}

class SujataAIApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sujata AI',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'OpenSans',
      ),
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
    );
  }
}
