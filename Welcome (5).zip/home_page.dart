
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sujata AI - Home')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ListTile(
            leading: Icon(Icons.search),
            title: Text('Wikipedia Search'),
            onTap: () {
              // Navigate to Wikipedia Search Page
            },
          ),
          ListTile(
            leading: Icon(Icons.web),
            title: Text('DuckDuckGo Search'),
            onTap: () {
              // Navigate to DuckDuckGo Search Page
            },
          ),
          ListTile(
            leading: Icon(Icons.code),
            title: Text('Code Snippets'),
            onTap: () {
              // Navigate to Code Snippets Page
            },
          ),
          ListTile(
            leading: Icon(Icons.trending_up),
            title: Text('Stock Market Analysis'),
            onTap: () {
              // Navigate to Stock Market Page
            },
          ),
          ListTile(
            leading: Icon(Icons.image),
            title: Text('AI Image Generation'),
            onTap: () {
              // Navigate to AI Image Generation Page
            },
          ),
          ListTile(
            leading: Icon(Icons.mic),
            title: Text('Voice Commands'),
            onTap: () {
              // Navigate to Voice Commands Page
            },
          ),
        ],
      ),
    );
  }
}
