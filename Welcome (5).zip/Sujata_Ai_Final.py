import os
import subprocess
import gradio as gr
import nltk
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Ensure required packages are installed
def install_dependencies():
    packages = [
        "numpy==1.23.5", "pandas==1.5.3", "scipy==1.10.1", "scikit-learn==1.2.2", "gradio==4.44.1",
        "nltk==3.8.1", "pillow==10.4.0"
    ]
    for package in packages:
        subprocess.run(["pip", "install", package, "--no-cache-dir"], check=True)

# Install dependencies before running
install_dependencies()

# Download necessary NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Sample chatbot class
class SujataAI:
    def __init__(self):
        self.vectorizer = CountVectorizer()
        self.responses = {
            "hello": "Hi there! How can I help you?",
            "how are you": "I'm just a bot, but I'm doing great! How about you?",
            "bye": "Goodbye! Have a great day!"
        }
        self.train()

    def train(self):
        questions = list(self.responses.keys())
        self.X = self.vectorizer.fit_transform(questions)

    def get_response(self, user_input):
        user_vec = self.vectorizer.transform([user_input])
        similarities = cosine_similarity(user_vec, self.X)
        best_match = np.argmax(similarities)
        return list(self.responses.values())[best_match]

sujata = SujataAI()

def chatbot_interface(user_input):
    return sujata.get_response(user_input)

demo = gr.Interface(fn=chatbot_interface, inputs="text", outputs="text", title="Sujata AI Chatbot")

demo.launch()
